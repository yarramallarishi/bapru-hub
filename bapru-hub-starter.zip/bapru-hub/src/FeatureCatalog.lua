-- This catalog preserves recognizable feature categories from the reference project
-- as UI entries only. Each entry is intentionally informational/inert until you
-- connect it to legitimate functionality in a Roblox experience you own.

return {
    {
        Name = "Dashboard",
        Icon = "⌂",
        Description = "Player and session overview",
        Items = {
            { Id = "session_status", Name = "Session status", Kind = "label", Default = "Ready" },
            { Id = "show_notifications", Name = "Desktop notifications", Kind = "toggle", Default = true },
        },
    },
    {
        Name = "Visuals",
        Icon = "◈",
        Description = "Client-side presentation preferences",
        Items = {
            { Id = "visual_indicators", Name = "Visual indicators", Kind = "toggle", Default = false },
            { Id = "visual_intensity", Name = "Visual intensity", Kind = "slider", Min = 0, Max = 100, Default = 65 },
        },
    },
    {
        Name = "Utilities",
        Icon = "✦",
        Description = "General interface utilities",
        Items = {
            { Id = "compact_mode", Name = "Compact mode", Kind = "toggle", Default = false },
            { Id = "ui_scale", Name = "UI scale", Kind = "slider", Min = 75, Max = 125, Default = 100 },
        },
    },
    {
        Name = "Progress",
        Icon = "▤",
        Description = "Progress and checklist panels",
        Items = {
            { Id = "show_progress_panel", Name = "Show progress panel", Kind = "toggle", Default = true },
        },
    },
    {
        Name = "Settings",
        Icon = "⚙",
        Description = "Application preferences",
        Items = {
            { Id = "reduce_motion", Name = "Reduce motion", Kind = "toggle", Default = false },
            { Id = "show_debug_log", Name = "Show debug log", Kind = "toggle", Default = false },
        },
    },
}
